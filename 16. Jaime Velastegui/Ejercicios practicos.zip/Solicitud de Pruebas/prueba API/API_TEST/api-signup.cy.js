describe ('API SIGNUP',()=>{
    it ('create user', ()=>{
  cy.request({
    method: 'POST',
    url: 'https://api.demoblaze.com/signup',
    body: {
    "username":"aksddfdfsd2",
    "password": "225njjbhghe"
  }

  }).then((res)=>{
   cy.log(JSON.stringify(res))
  expect(res.status).to.eq(200)
  
  }) 
})
})