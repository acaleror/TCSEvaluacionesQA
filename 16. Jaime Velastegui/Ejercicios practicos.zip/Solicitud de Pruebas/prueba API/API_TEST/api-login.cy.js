describe ('API LOGIN',()=>{
    it ('Verify User', ()=>{
  cy.request({
    method: 'POST',
    url: 'https://api.demoblaze.com/login',
    body: {
    "username":"aks@ddfdfsd2",
    "password": "225@njjbhghe"
  }

  }).then((res)=>{
   cy.log(JSON.stringify(res))
  expect(res.status).to.eq(200)
  
  }) 
})
})