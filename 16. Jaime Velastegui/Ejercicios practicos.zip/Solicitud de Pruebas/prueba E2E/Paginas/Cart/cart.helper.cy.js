import { CartElements } from "./cart.elements.cy";

export class CartHelper {
    static clickOnPlaceOrderButton(){
        CartElements.elements.placeorderButton.click();
    }
}