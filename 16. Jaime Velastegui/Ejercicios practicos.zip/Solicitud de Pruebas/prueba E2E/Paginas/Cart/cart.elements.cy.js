export class CartElements{
    static get elements (){
        return{
            get placeorderButton(){
                return  cy.get('button[data-toggle="modal"]');
        },
    };
    }
}