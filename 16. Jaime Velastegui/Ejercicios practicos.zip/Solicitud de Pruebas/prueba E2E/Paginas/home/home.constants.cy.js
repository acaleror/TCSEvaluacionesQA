export class HomeConstants{
    static get testData(){
        return{
            productName: "Samsung galaxy s6",
        };
    }
}