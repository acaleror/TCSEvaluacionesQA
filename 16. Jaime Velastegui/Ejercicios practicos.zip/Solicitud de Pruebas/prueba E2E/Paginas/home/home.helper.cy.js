import { HomeElements } from "./home.elements.cy";

export class HomeHelper{
    static clickOnProductName(productName){
        HomeElements.elements.productLink(productName).click();  //product link recine el parametro de producname
    }
}