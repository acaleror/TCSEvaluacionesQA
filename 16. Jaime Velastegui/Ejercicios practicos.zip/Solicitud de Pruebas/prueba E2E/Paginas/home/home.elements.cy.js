export class HomeElements{
static get elements(){
    return{
    // aqui no se pone get por que tiene un parametro
    productLink(productName){return cy.contains ('a', productName);
    }
    };
}
}