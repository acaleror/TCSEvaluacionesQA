import { CartElements } from "../Cart/cart.elements.cy";
import { CartHelper } from "../Cart/cart.helper.cy";
import { CommonPageHelper } from "../Paginas comunes/common-page.helper.cy"
import { singUpConstants } from "../Sing-up/sing-up.constants.cy";
import { SingUpHelper } from "../Sing-up/sing-up.helper.cy";
import { HomeConstants } from "../home/home.constants.cy";
import { HomeHelper } from "../home/home.helper.cy";
import { HomeConstants2 } from "../home2/home2.constants.cy";
import { HomeHelper2 } from "../home2/home2.helper.cy";
import { LoginHelper } from "../login/login.helper.cy";
import { PlaceOrderConstants } from "../place.order/place-order.constants.cy";
import { PlaceOrderHelper } from "../place.order/place-order.helper.cy";
import { ProductHelper } from "../productos/producto.helper.cy";

describe ("Place order", ()=>{
it ("place order con creacion de usuario nuevo", () => {
    const username = CommonPageHelper.generateRandmString();
    const password = CommonPageHelper.generateRandmString();
const productName = HomeConstants.testData.productName;
const productNametwo =HomeConstants2.testData2.productNametwo;
const orderTestData = PlaceOrderConstants.testData;
    // cra una cuenta
    CommonPageHelper.navigaToTheApplication();
    CommonPageHelper.clickOnSingUpoption();
    SingUpHelper.insertUsername (username);
    SingUpHelper.insertPasword (password); 
    SingUpHelper.clickOnSingUpButton();

    // loguearse con la cuenta creada 

    CommonPageHelper.clickOnLoginoption();
    LoginHelper.insertUsername(username);
    LoginHelper.insertPasword(password);
    LoginHelper.clikButton();
    
// llamar metodo de verificacion de usuario
CommonPageHelper.verifySignedUser(username); // da error cuando no es el usuario (reeemplazar el username por otro nombre)
   
   
   // ir al homepage y hacer click en un producto

   CommonPageHelper.cliickOnHomePage();
   HomeHelper.clickOnProductName (productName)        //aqui s le hace click al producto
   ProductHelper.clickOnAddToProductButton();  //aqui se anade el producto

   // 2 do producto

   CommonPageHelper.cliickOnHomePage();
   HomeHelper2.clickOnProductName2(productNametwo);
   ProductHelper.clickOnAddToProductButton();  //aqui se anade el producto
   
 
       CommonPageHelper.clickOncartOption();
   CartHelper.clickOnPlaceOrderButton();

   PlaceOrderHelper.insertName(orderTestData.name)
   PlaceOrderHelper.insertCountry(orderTestData.country)
   PlaceOrderHelper.insertCity(orderTestData.city)
   PlaceOrderHelper.insertCreditCard(orderTestData.creditCard)
   PlaceOrderHelper.insertMonth(orderTestData.month)
   PlaceOrderHelper.insertYear(orderTestData.year)
   PlaceOrderHelper.clickOnPurchaseButton();

   
   cy.wait(2000);


   


    

});

});