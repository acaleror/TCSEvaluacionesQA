export class LoginElements{
    //creamos los elementos estaticos de la pagna (los id o web id de los elementos)
    static get elements (){ 
        return {
            get username(){
                return cy.get('input#loginusername');
            },
              //este elemento es para el pasword
            get password (){
                return cy.get('input#loginpassword');
            },
            //este es para el click de login boton
            get loginButton(){
                return cy.contains('button', 'Log in')
            },

        };

    }
}