import { LoginElements } from "./login.elements.cy";

export class LoginHelper{
    //aqui creamos los metodos para llamar al usrname de los elements
    static insertUsername(username){
        LoginElements.elements.username.click();
        LoginElements.elements.username.type(username);
    }

static insertPasword(password){
    LoginElements.elements.password.click();
    LoginElements.elements.password.type(password);
}

static clikButton(){
    LoginElements.elements.loginButton.click();

}

}