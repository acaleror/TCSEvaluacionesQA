import { ProductElements } from "./producto.elemets.cy";

export class ProductHelper{
    static  clickOnAddToProductButton(){
        ProductElements.elements.addToCartButton.click();
    }
}