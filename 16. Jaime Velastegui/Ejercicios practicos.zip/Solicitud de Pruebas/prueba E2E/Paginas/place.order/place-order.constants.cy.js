export class PlaceOrderConstants{
    static get testData(){
return{
    name:'TEST',
    country: 'ECUADOR',
    city: 'QUITO',
    creditCard: '378282246310005',
    month: '07',
    year: '2024',

}
    }
}