export class CommonPageElements {
    // web elements
    static get topMenu(){
        return{
            get singUp(){return cy.get('a[data-target="#signInModal"]');
        },

   // aqui creamos la opcion de login del menu principal
    get login(){ return cy.get('a[data-target="#logInModal"]');
         }    , 
// para verific,ar el usuario logueado
get nameOfUser(){

    return cy.get("#nameofuser");  // aqui se busca por id del elemento

},

//creamos nueva opcion de menu home page

get home (){
    return cy.contains("a", "Home");
},

// craemos la opcion de carrito de compras

get cart (){
    return cy.get('a#cartur');
},
        };
    }
}