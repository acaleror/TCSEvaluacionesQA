import { CommonPageConstants } from "./common-page.constants.cy";
import { CommonPageElements } from "./common-page.elements.cy";

export class CommonPageHelper{
    //llamamos a la ul
    static navigaToTheApplication(){
        cy.visit(CommonPageConstants.applicationUrl);
    }
static clickOnSingUpoption(){
    CommonPageElements.topMenu.singUp.click();
            }

     //aqui llamamos al metodo para dar click en el menu principal la opcion login
            static clickOnLoginoption (){
                CommonPageElements.topMenu.login.click();
            }


     //verificar el usuario

     static verifySignedUser (username){
        CommonPageElements.topMenu.nameOfUser.should('contain',`Welcome ${username}`);

     }

     // dar click en el menu de homepage

     static cliickOnHomePage(){
        CommonPageElements.topMenu.home.click();
     }

// metodo para click en el carrito

static clickOncartOption(){
    CommonPageElements.topMenu.cart.click();
}

//metodo para generar usuarios ramdom

static generateRandmString = (lenght = 10) => {
    let result = "";
    const characters = "bcdefghijklmnopqrstuvwxyz0123456789";
    const charactersLength = characters.length;
    let counter = 0;
    while (counter < lenght) {
        result += characters.charAt(Math.floor(Math.random() * characters.length));
        counter += 1;

    }
    return result;
     };
}
