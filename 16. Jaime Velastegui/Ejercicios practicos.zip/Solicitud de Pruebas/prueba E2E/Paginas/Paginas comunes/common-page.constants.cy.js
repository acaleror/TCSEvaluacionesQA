export class CommonPageConstants{
    static get applicationUrl(){
        return "https://www.demoblaze.com";
    }
}