import { SingUpElements } from "./sing-up.elements.cy";

export class SingUpHelper{
    
// crear metodos para insertar los nombres

static insertUsername (username)
{SingUpElements.elemets.username.click();
    SingUpElements.elemets.username.type(username);
}

static insertPasword(password)
{SingUpElements.elemets.password.click();
    SingUpElements.elemets.password.type(password)
}


static clickOnSingUpButton(){
    SingUpElements.elemets.singUpButton.click();
}

}