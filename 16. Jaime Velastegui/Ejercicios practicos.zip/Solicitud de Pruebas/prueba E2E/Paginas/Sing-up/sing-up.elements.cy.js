export class SingUpElements{
    static get elemets (){
     return {
        get username(){return cy.get('input#sign-username');},
     
     get  password (){return cy.get('input#sign-password');
    },
    get singUpButton ()
    {return cy.contains('button', 'Sign up');
}
     };

    }
}

//cy.contains('button', 'Sign up')

