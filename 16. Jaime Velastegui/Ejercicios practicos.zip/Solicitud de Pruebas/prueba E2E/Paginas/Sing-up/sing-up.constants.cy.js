export class singUpConstants {
    static get testData(){
        return {
         };
    }
}