export class HomeConstants2{
    static get testData2(){
        return{
            productNametwo: "Nexus 6",
        };
    }
} 