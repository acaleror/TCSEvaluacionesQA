import { HomeElements2 } from "./home2.elements.cy";

export class HomeHelper2{
    static clickOnProductName2(productNametwo){
         //product link recine el parametro de producname
    HomeElements2.elements.productLink(productNametwo).click();
    }
}