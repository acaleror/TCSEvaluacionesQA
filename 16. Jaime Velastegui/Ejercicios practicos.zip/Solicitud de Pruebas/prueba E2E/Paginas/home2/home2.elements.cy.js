export class HomeElements2{
    static get elements(){
        return{
        // aqui no se pone get por que tiene un parametro
        productLink(productNametwo){return cy.contains ('a',productNametwo);
        }
        };
    }
    } 