Instrucciones de ejecución:
* Copiar la carpeta con el nombre Páginas dentro del path E2E de Cypress.
*Ejecutar el framework Cypress y escoger el browswer puede ser electron, edge o firefox.
* Al abrir el framework en la pestaña Specs escoger la carpeta previamente copiada Paginas y buscar la carpeta Test y dar click o ejecutar el archivo place-order.cy.js.
