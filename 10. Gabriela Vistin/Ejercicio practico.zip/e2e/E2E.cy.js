describe('shopping cart', () => {
  it('succesful login', () => {
    cy.visit('https://www.demoblaze.com/');
    cy.wait(2000)

    cy.get(':nth-child(8) > .card > :nth-child(1) > .card-img-top').click()
    cy.wait(4000).get('.col-sm-12 > .btn').click()
    cy.visit('https://www.demoblaze.com/')
    cy.wait(3000)

    cy.get(':nth-child(3) > .card > :nth-child(1) > .card-img-top').click()
    cy.wait(4000).get('.col-sm-12 > .btn').click()
    cy.visit('https://www.demoblaze.com/')
    cy.wait(3000)

    cy.get('#cartur').click()
    
    cy.get('.col-lg-1 > .btn').click()
    cy.wait(1200)

    cy.get('#orderModalLabel').should('have.text', 'Place order')

    cy.get('#name').type('Gabriela Vistin');
    cy.get('#country').type('Ecuador');
    cy.get('#city').type('Quito');
    cy.get('#card').type('4567 4567 0910 1234');
    cy.get('#month').type('08');
    cy.get('#year').type('2027');

    cy.get('#orderModal > .modal-dialog > .modal-content > .modal-footer > .btn-primary').click()
    cy.wait(1000)

    cy.get('.confirm').click()
    
    cy.visit('https://www.demoblaze.com/');
    
    })
})