describe('Capturing data sent by the form via POST method', () => {
  beforeEach(() => {
    Cypress.config('baseUrl', 'https://www.demoblaze.com/');
    //cy.server();
    //cy.route({
      //method: 'POST',
      //url: 'https://api.demoblaze.com/signup'
      cy.intercept('POST', 'https://api.demoblaze.com/login', (req)=> {
          req.on('response', (res) => {
              res.setDelay(500)
          })
          //req.body.'test': 'We’ll'
    }).as('loginuser');
  });
  it('should capture the login and password', () => {
      cy.visit('https://www.demoblaze.com/');
      cy.get('#login2').click();
      cy.get('#loginusername').type ('Gabriela123');
      cy.get('#loginpassword').type ('Aroma123');
      cy.get('#logInModal > .modal-dialog > .modal-content > .modal-footer > .btn-primary').click()
      cy.visit('https://www.demoblaze.com/');
    //cy.get('#loginUsername').type('prueba1');
    //cy.get('#loginPassword').type('prueba1');
    //cy.get('button[type="submit"]').click();

    cy.wait('@loginuser')
    //.its('request.url').should('include', 'Signup')

    //.then(xhr => {
      //cy.log(xhr.responseBody);
      //cy.log(xhr.requestBody);
      //expect(xhr.method).to.eq('POST');

  });
  it('prueba login correcto', () => {
      cy.visit('https://www.demoblaze.com/');
      cy.get('#login2').click();
      cy.get('#loginusername').type ('Gabriela123');
      cy.get('#loginpassword').type ('Aroma345');
      cy.get('#logInModal > .modal-dialog > .modal-content > .modal-footer > .btn-primary').click()
      cy.visit('https://www.demoblaze.com/');
      //cy.get('#loginUsername').type('prueba1');
      //cy.get('#loginPassword').type('prueba1');
      //cy.get('button[type="submit"]').click();
  
      cy.wait('@loginuser')
      //.its('request.url').should('include', 'Signup')

      //.then(xhr => {
        //cy.log(xhr.responseBody);
        //cy.log(xhr.requestBody);
        //expect(xhr.method).to.eq('POST');

    });
});