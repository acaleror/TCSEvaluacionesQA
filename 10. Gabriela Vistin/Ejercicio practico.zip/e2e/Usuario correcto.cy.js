describe('Capturing data sent by the form via POST method', () => {
  beforeEach(() => {
    Cypress.config('baseUrl', 'https://www.demoblaze.com/');
      cy.intercept('POST', 'https://api.demoblaze.com/signup', (req)=> {
          req.on('response', (res) => {
              res.setDelay(500)
          })
      
    }).as('Signupuser');
  });
  it('Crear nuevo usuario signup', () => {
    cy.visit('https://www.demoblaze.com/');
    cy.get('#signin2').click();
    cy.get('#sign-username').type('Gabriela23');
    cy.get('#sign-password').type('Gabriela23');
    cy.get('#signInModal > .modal-dialog > .modal-content > .modal-footer > .btn-primary').click();
    
    cy.wait('@Signupuser')
    

  });
  it('prueba usuario o password existente', () => {
      cy.visit('https://www.demoblaze.com/');
      cy.get('#signin2').click();
      cy.get('#sign-username').type('Gabriela123');
      cy.get('#sign-password').type('Aroma123');
      cy.get('#signInModal > .modal-dialog > .modal-content > .modal-footer > .btn-primary').click();
  
      cy.wait('@Signupuser')

    });
});