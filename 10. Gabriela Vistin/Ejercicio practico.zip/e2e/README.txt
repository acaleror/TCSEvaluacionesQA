## INTRODUCCION

Realizar la compra mediante una página
Ingresar con usuario correcto
Ingresar con usuario incorrecto

## REQUERIMIENTOS

Este módulo requiere los siguientes:

Acceder a la url de compra https://www.demoblaze.com/

Ingresar con el usuario y contraseña creado validación de usuario correcto

Se pueda seleccionar los productos

Se configure los tiempos de espera

Se pueda añadir los productos al carrito

Se pueda ingresar la forma de pago

Se finalice la compra de manera exitosa

Ingresar con el usuario y contraseña incorrecta, no permita ingresar a la compra

## INSTALACION

Programa visual code

Cypress o (Serenity o Karate)

Crear la sentencia para acceso a la url de compras, incluye tiempos de espera, selección de productos y forma de pago

Crear la sentencia para ingreso con usuario correcto e incorrecto

## RESULTADO

Compra exitosa