package com.cristhian.www.utils;

import com.cristhian.www.configurations.DriverConfig;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;

import java.time.Duration;

public class Actions {

    public static WebElement fluentWait(String elementWait, String nameElement) {
        try {
            Wait<WebDriver> fwait = new FluentWait<WebDriver>(DriverConfig.getDriver())
                    .withTimeout(Duration.ofSeconds(20))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            WebElement element = fwait.until(ExpectedConditions.elementToBeClickable(DriverConfig.getDriver().findElement(By.xpath(elementWait))));
            return element;
        } catch (Exception e) {
            Assert.fail("No se encontro el elemento " + nameElement);
            return null;
        }
    }

    public static WebElement fluentWaitElement(WebElement elementWait, String nameElement) {
        try {
            Wait<WebDriver> fwait = new FluentWait<WebDriver>(DriverConfig.getDriver())
                    .withTimeout(Duration.ofSeconds(40))
                    .pollingEvery(Duration.ofSeconds(2))
                    .ignoring(NoSuchElementException.class);
            WebElement element = fwait.until(ExpectedConditions.elementToBeClickable(elementWait));
            return element;
        } catch (Exception e) {
            Assert.fail("No se encontro el elemento " + nameElement);
            return null;
        }
    }

    public static WebElement findElement(String element, String nameElement) {
        try {
            for (int i = 0; i < 4; i++) {
                Thread.sleep(1000);
                if (DriverConfig.getDriver().findElement(By.xpath(element)).isDisplayed()) {
                    return DriverConfig.getDriver().findElement(By.xpath(element));
                }
            }
        } catch (Exception e) {

        }
        Assert.fail("No se encontro el elemento " + nameElement);
        return null;

    }

    public static void waitForm() {
        try {
                Thread.sleep(1000);
        } catch (Exception e) {

        }

    }

}
