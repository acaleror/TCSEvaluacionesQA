package com.cristhian.www.configurations;

import io.restassured.RestAssured;
import io.restassured.config.RestAssuredConfig;
import io.restassured.filter.Filter;
import io.restassured.http.*;
import io.restassured.mapper.ObjectMapper;
import io.restassured.mapper.ObjectMapperType;
import io.restassured.response.Response;
import io.restassured.specification.*;
import org.checkerframework.checker.units.qual.C;

import java.io.File;
import java.io.InputStream;
import java.security.KeyStore;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public class ServiceConfig {

    RequestSpecification request;
    Response response;
    ContentType contentType;

    public ServiceConfig() {

    }
    public int testResponsecode(String body, String endPoint) {

        RestAssured.baseURI = endPoint;
        contentType = ContentType.JSON;
        request = RestAssured.given().contentType(contentType).accept(contentType);
        request.body(body);
        request.put(endPoint);
        response = (Response) request.post(endPoint,new Object[0]);
        System.out.println(" Status code is " + response.getStatusCode());
        System.out.println();
        return response.getStatusCode();
    }

    public String getTag(String value){
        return response.andReturn().getBody().jsonPath().getString(value);
    }
}
