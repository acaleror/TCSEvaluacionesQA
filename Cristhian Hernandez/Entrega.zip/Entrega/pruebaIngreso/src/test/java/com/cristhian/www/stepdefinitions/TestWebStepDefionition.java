package com.cristhian.www.stepdefinitions;

import com.cristhian.www.configurations.DriverConfig;
import com.cristhian.www.pages.DemoBlazePage;
import com.cristhian.www.pages.PlaceOrderPage;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import java.sql.Driver;
import java.util.List;

import static com.cristhian.www.utils.Actions.*;


public class TestWebStepDefionition {

    private DemoBlazePage demoBlazePage;
    private List<List<String>> rows;
    private PlaceOrderPage placeOrderPage;

    public TestWebStepDefionition() {
        demoBlazePage = new DemoBlazePage();
        placeOrderPage = new PlaceOrderPage();
    }

    @Given("^Ingreso a la pagina DemoBlaze$")
    public void getBlazePage() {
        DriverConfig.getDriver().get("https://www.demoBlaze.com/");
        DriverConfig.getDriver().manage().window().maximize();
    }

    @And("^Agrego los productos al carrito:$")
    public void addProducts(DataTable products) {
        rows = products.asLists(String.class);
        for (List<String> productsData : rows) {
            findElement(demoBlazePage.getProduct(productsData.get(1)), "Tipo producto").click();
            findElement(demoBlazePage.getProduct(productsData.get(0)), "Tipo producto").click();
            fluentWaitElement(demoBlazePage.getBtnAdd(), "Add products ");
            demoBlazePage.getBtnAdd().click();
            demoBlazePage.getLblHome().click();
        }
    }

    @When("^verifico el carrito de compra con los productos$")
    public void loadBascketOfProducts() {
        demoBlazePage.getLblCart().click();
        fluentWaitElement(demoBlazePage.getBtnPlaceOrder(), "boton ordenar");
        fluentWaitElement(demoBlazePage.getBtnDelete(), "boton eliminar");

        int cont = 0;
        for (List<String> productsData : rows) {
            for (int column = 0; column < demoBlazePage.getLblTableCart().size(); column++) {
                if (productsData.get(0).contains(demoBlazePage.getLblTableCart().get(column).getText())) {
                    System.out.println("Se añadio de fora correcta el producto encontro el producto " + productsData.get(0));
                    break;
                } else if (column == demoBlazePage.getLblTableCart().size() - 1) {
                    System.out.println("No se añadio de forma correcta el producto " + productsData.get(0));
                }
            }
        }

    }

    @And("^Completo el formulario de compra$")
    public void fillOutPurchasingForm() {
        demoBlazePage.getBtnPlaceOrder().click();
        fluentWaitElement(placeOrderPage.getInputName(), "Input nombre formulario de compra");
        placeOrderPage.getInputName().sendKeys("Cristhian");
        placeOrderPage.getInputCountry().sendKeys("Colombia");
        placeOrderPage.getInpuCity().sendKeys("Bogota");
        placeOrderPage.getInputcreditCard().sendKeys("133151616");
        placeOrderPage.getInputMonth().sendKeys("133151616");
        placeOrderPage.getInpuYear().sendKeys("2023");
        waitForm();
        placeOrderPage.getBtnPurchase().click();

    }

    @Then("^Finalizo la compra$")
    public void finalizaPurchase() {
       DriverConfig.closeNavigator();
    }


}
