package com.cristhian.www.pages;

import com.cristhian.www.configurations.DriverConfig;
import lombok.Data;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

@Data
public class DemoBlazePage {

    public DemoBlazePage() {
        PageFactory.initElements(DriverConfig.getDriver(), this);
    }

    @FindBy(xpath = "//a[contains(text(),'Add to cart')]")
    private WebElement btnAdd;

    public String getProduct(String product) {
        return "//a[contains(text(),'" + product + "')]";
    }

    @FindBy(xpath = "//a[contains(@href,'index.html')]")
    private WebElement lblHome;

    @FindBy(xpath = "//a[contains(@href,'cart.html')]")
    private WebElement lblCart;

    @FindBy(xpath = "//table//td[2]")
    private List<WebElement> lblTableCart;

    @FindBy(xpath = "//button[contains(text(),'Place Order')]")
    private WebElement btnPlaceOrder;

    @FindBy(xpath = "//a[contains(text(),'Delete')]")
    private WebElement btnDelete;

}
