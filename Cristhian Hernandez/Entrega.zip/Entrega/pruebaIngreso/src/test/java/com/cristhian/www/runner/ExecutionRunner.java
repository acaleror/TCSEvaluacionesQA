package com.cristhian.www.runner;

import io.cucumber.junit.Cucumber;
import org.junit.Test;

import static io.cucumber.core.cli.Main.run;

public class ExecutionRunner {

    @Test
    public void execute() {
        runner(System.getProperty("Case"));
    }

    private void runner(String tag) {
        String[] runnerConfig = {
                "src/test/resources/features",
                "--glue", "com.cristhian.www.stepdefinitions",
                "--tags", "@" + tag,
        };
        run(runnerConfig, Cucumber.class.getClassLoader());
    }

}
