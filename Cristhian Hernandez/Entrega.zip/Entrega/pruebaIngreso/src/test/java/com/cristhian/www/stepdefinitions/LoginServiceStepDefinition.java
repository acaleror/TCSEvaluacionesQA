package com.cristhian.www.stepdefinitions;

import com.cristhian.www.configurations.ServiceConfig;
import com.cristhian.www.dto.LoginDto;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;

public class LoginServiceStepDefinition {

    private LoginDto loginDto;
    private ServiceConfig serviceConfig;
    private int statusCode;

    public LoginServiceStepDefinition() {
        loginDto = new LoginDto();
        serviceConfig = new ServiceConfig();
    }


    @Given("^Se registran los datos (.*) y (.*)$")
    public void setData(String usuario, String contra) {
        loginDto.setData(usuario, contra);
    }

    @When("^Se configura el servicio para logueo exitoso$")
    public void setConfigurations() {
        statusCode = serviceConfig.testResponsecode(loginDto.getRequest(), "https://api.demoblaze.com/login");
    }

    @Then("^verifico el login exitoso$")
    public void verifyResponse() {
        if (statusCode == 200) {
            System.out.println("Consumo exitoso con codigo " + statusCode);
            if (serviceConfig.getTag("errorMessage").contains("Wrong")) {
                Assert.fail("No se consulto el usuairo con exito " + serviceConfig.getTag("errorMessage"));
            }
        } else {
            System.out.println("Se realiza loguin Exitoso" + serviceConfig.getTag("errorMessage"));
        }
    }


}
