package com.cristhian.www.configurations;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.io.File;

public class DriverConfig {

    private static WebDriver webDriver;

    public static ChromeOptions setInitParameters() {
        File actuallDirectory = new File(".");
        String path = actuallDirectory.getAbsolutePath();
        System.setProperty("webdriver.chrome.driver",
                path.substring(0, path.length() - 1) + "src\\test\\resources\\driver\\chromedriver.exe");
        ChromeOptions chOptions = new ChromeOptions();
        chOptions.addArguments(new String[]{"--disable-notifications"});
        chOptions.addArguments(new String[]{"--no-sandbox"});
        chOptions.addArguments(new String[]{"--disable-dev-shm-usage"});
        chOptions.addArguments(new String[]{"--remote-allow-origins=*"});
        return chOptions;
    }

    public static WebDriver getDriver() {
        if (webDriver == null) {
            webDriver = new ChromeDriver(setInitParameters());
        }
        return webDriver;
    }

    public static void closeNavigator() {
        webDriver.close();
        webDriver.quit();
        webDriver = null;
    }

}
