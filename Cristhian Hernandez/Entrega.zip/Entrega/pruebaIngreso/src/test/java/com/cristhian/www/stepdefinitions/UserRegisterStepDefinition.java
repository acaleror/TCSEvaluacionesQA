package com.cristhian.www.stepdefinitions;

import com.cristhian.www.configurations.ServiceConfig;
import com.cristhian.www.dto.LoginDto;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.junit.Assert;

public class UserRegisterStepDefinition {
    private LoginDto loginDto;
    private ServiceConfig serviceConfig;
    private int statusCode;

    public UserRegisterStepDefinition() {
        loginDto = new LoginDto();
        serviceConfig = new ServiceConfig();
    }

    @Given("^Se registran los datos para el registro <usuario> y <contrase�a>$")
    public void setData(String usuario, String contra) {
        loginDto.setData("username", contra);
        loginDto.setData("password", contra);
    }

    @And("^Se configura el servicio para registro usuario$")
    public void setConfigurations() {
        statusCode = serviceConfig.testResponsecode(loginDto.getRequest(), "https://api.demoblaze.com/signup");
    }

    @Then("^Verificao el registro exitoso$")
    public void verifyResponse() {
        if (statusCode == 200) {
            System.out.println("Consumo exitoso");
            if (serviceConfig.getTag("errorMessage").contains("This user already exist.")) {
                Assert.fail("No se consulto el usuairo con exito " + serviceConfig.getTag("errorMessage"));
            } else {
                System.out.println("Se recibe mensaje " + serviceConfig.getTag("errorMessage"));
            }
        } else {
            System.out.println("Se realiza loguin fallido");
        }
    }

}
