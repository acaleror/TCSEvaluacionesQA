package com.cristhian.www.pages;

import com.cristhian.www.configurations.DriverConfig;
import lombok.Data;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

@Data
public class PlaceOrderPage {

    public PlaceOrderPage() {
        PageFactory.initElements(DriverConfig.getDriver(), this);
    }

    @FindBy(xpath = "//label[text()='Name:']/following-sibling::input")
    private WebElement inputName;

    @FindBy(xpath = "//label[text()='Country:']/following-sibling::input")
    private WebElement inputCountry;

    @FindBy(xpath = "//label[text()='Credit card:']/following-sibling::input")
    private WebElement inputcreditCard;

    @FindBy(xpath = "//label[text()='Month:']/following-sibling::input")
    private WebElement inputMonth;

    @FindBy(xpath = "//label[text()='Year:']/following-sibling::input")
    private WebElement inpuYear;

    @FindBy(xpath = "//label[text()='City:']/following-sibling::input")
    private WebElement inpuCity;

    @FindBy(xpath = "//Button[contains(text(),'Purchase')]")
    private WebElement btnPurchase;



}
