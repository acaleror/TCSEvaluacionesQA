package com.cristhian.www.dto;

import java.util.HashMap;

public class LoginDto {

    HashMap<String, String> datos;
    public LoginDto() {
        datos = new HashMap<String, String>();
    }
    public void setData(String key, String value) {
        datos.put(key, value);
    }
    public String getRequest() {
        return "{\n" +
                "\t\"username\":\"" + datos.get("username") + "\",\n" +
                "\t\"password\":\"" + datos.get("password") + "\"\n" +
                "}";
    }
}
