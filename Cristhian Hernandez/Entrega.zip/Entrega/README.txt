El proyecto cuenta con implementaciones 
1. Java  --> open jdk  20
2. MVN --> apache-maven-3.9.5
3. Cucumber 
5. gherky
6. Patron POM
7. Dados los anteriores datos el equipo de ejecucion debera contar con las variables de entorno configuradas para el jdk y maven
