/// <reference
describe('shopping  cart', () =>{
    it('successful login', ()=>{
        cy.visit('https://www.demoblaze.com/index.html');
    });
});