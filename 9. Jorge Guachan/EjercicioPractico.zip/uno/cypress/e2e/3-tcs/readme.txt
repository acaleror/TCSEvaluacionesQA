

Versión de Node v14.20.0

Los pasos que se tiene que realizar son los siguientes.

1. abrir el terminal con la ruta /UNO/.
2. ejecutar el comando npm run cypress:open.
3. Validar que se abra la pantalla de cypress.
4. Dar clic en la opción E2E Testing.
5. Dar clic en Star E2E Testing in Chrome.
6. Validar que se abra la pantalla de chrome con las opciones Specs-Runs-debug-Seting.
7. Dar clic en specs y buscar el archivo 3-tcs/compra-cart.cy.js.
8. Validar que se ejecuta la prueba correctamente.