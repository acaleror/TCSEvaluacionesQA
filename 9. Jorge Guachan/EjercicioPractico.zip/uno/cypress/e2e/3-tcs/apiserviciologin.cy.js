///Api Servicios
const endPoint = 'https://api.demoblaze.com/signup';
const todoObject={
    "username":"jagi1205",
    "password":"jagi1205"
}
const addUser = todoObject => {
    cy.request('POST', endPoint,todoObject)
}
describe('API TESTING',()=>
{
    it('Add User',()=>{
        addUser(todoObject)
        cy.request('GET','${endPoint}/$todoObject.username}')
        .its('body')
        .should('deep.eq', todoObject)  });
  
});