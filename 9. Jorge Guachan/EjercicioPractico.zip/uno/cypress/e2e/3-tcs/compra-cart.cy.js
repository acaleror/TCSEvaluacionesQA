/// EJERCICIO UNO
const validuser={
    usuario:'admin',
    clave:'admin',
};

describe('shopping  cart', () =>{
    it('successful login', ()=>{
        cy.visit('https://www.demoblaze.com/index.html');
        cy.get('#login2').click();
        cy.get('#logInModalLabel').should('have.text','Log in',);
        cy.wait(3000)
        cy.get('#loginusername').type(validuser.usuario);
        cy.get('#logInModalLabel').should('have.text','Log in',);
        cy.get('#loginpassword').type(validuser.clave);
        cy.get('#logInModal > .modal-dialog > .modal-content > .modal-footer > .btn-primary').as('BotonLogin');
        cy.get('@BotonLogin').click();
        cy.get('#nameofuser').should('have.text','Welcome admin',);
        ///Agrega productos al carrito
        cy.get(':nth-child(1) > .card > .card-block > .card-title > .hrefch').should('have.text','Samsung galaxy s6',);
        cy.get(':nth-child(1) > .card > .card-block > .card-title > .hrefch').click();
        cy.get('#more-information > p').should('include.text','The Samsung Galaxy S6 is powered by 1.5GHz',);
        cy.get('.col-sm-12 > .btn').as('Botonagregaproducto');
        cy.get('@Botonagregaproducto').click();
        cy.get('.active > .nav-link').click();
        cy.get(':nth-child(3) > .card > .card-block > .card-title > .hrefch').should('have.text','Nexus 6',);
        cy.get(':nth-child(3) > .card > .card-block > .card-title > .hrefch').click();
        cy.get('#more-information > p').should('include.text','The Motorola Google Nexus 6 is powered by',);
        cy.get('@Botonagregaproducto').click();
        //Visualizar el carrito
        cy.get('#cartur').click();
        cy.get('.col-lg-1').should('include.text','Total',);
        cy.get('.col-lg-1 > .btn').click();

        ///Registro de Datos de Compra
        cy.get('#orderModalLabel').should('have.text','Place order',);
        cy.wait(2000)
        cy.get('#name').type('Jorge Guachan');
        cy.get('#country').type('Ecuador');
        cy.get('#city').type('Quito');
        cy.get('#card').type('1234 1234 1234 1234');
        cy.get('#month').type('05');
        cy.get('#year').type('2023');
        cy.get('#orderModal > .modal-dialog > .modal-content > .modal-footer > .btn-primary').as('Botoncompra');
        cy.get('@Botoncompra').click();
        /// Validar Compra realizada
        cy.get('.sweet-alert > h2').should('have.text','Thank you for your purchase!',);
        cy.get('.confirm').click();




    });
});