---------------------------------------------------------------
 Un readme
---------------------------------------------------------------

1. Prerequisitos:
** 
	- Maquina local con el sistema operativo Windows 10
	- Visual Studio Code
	- Node.js
	
2. Comandos de ejecución
**
	- npx cypress open 

3. Instrucciones para ejecutar los test
** - Abrir el visual studio code
   - cargar el archivo con nombre "Ejercicio 1 Isabel Tata.cy.js" dentro de la carpeta e2e
   - ejecutar el comando 
	


