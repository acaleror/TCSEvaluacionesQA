describe('template spec', () => 
{
  beforeEach(()=>
  {
   
    cy.visit('https://www.demoblaze.com/')

  })

  it("validar el ingreso a la página correcta",function()
  {
    cy.contains('Phones').log('Página correcta')
  })

  it("validar la selección de los 2 productos",function()
  {
    
    cy.get(':nth-child(2) > .card > .card-block > .card-title > .hrefch').click()
    cy.contains('Nokia lumia 1520').log('producto correcto') // se valida que el producto1 sea el seleccionado
    cy.get('#tbodyid :nth-child(7) div a').click()
    cy.get('.active > .nav-link').click()
    cy.get(':nth-child(5) > .card > .card-block > .card-title > .hrefch').click()
    cy.contains('Iphone 6 32gb').log('producto correcto') // se valida que el producto2 sea el seleccionado
    cy.get('.col-sm-12 > .btn').click()
    cy.get('#cartur').click() //visualizacion del carrito
    cy.get('.col-lg-1 > .btn').click()
    cy.get('#name').type('Isabel') //Completar el formulario de compras
    cy.get('#country').type('cuba')
    cy.get('#city').type('Holguin')
    cy.get('#card').type('123456781234')
    cy.get('#month').type('Agosto')
    cy.get('#year').type('2023')
    cy.get('#orderModal > .modal-dialog > .modal-content > .modal-footer > .btn-primary').click()
    cy.contains('Thank you for your purchase!').log('orden correcta')
    cy.contains('Amount: 1610 USD').log('orden correcta')// finalizada la compra
    cy.wait(5000)
    cy.get('.confirm').click()
 
  })


 


})