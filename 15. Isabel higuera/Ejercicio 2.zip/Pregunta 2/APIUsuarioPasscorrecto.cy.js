describe("Crear Nuevo Usuario",()=>{

    it("Post Crear usuario signup",()=>{
        cypress.request({
            method:'POST',
            url:'https://api.demoblaze.com/login',
            body:{
                username:"imhiguera12",
                password:"12345"
            }

        })
        .its('status')
        .should('equal',200);

    })


})