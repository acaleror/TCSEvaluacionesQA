---------------------------------------------------------------
 Un readme
---------------------------------------------------------------

1. Prerequisitos:
** 
	- Maquina local con el sistema operativo Windows 10
	- Visual Studio Code
	- Node.js
	
2. Comandos de ejecución
**
	- npx cypress open 

3. Instrucciones para ejecutar los test
** - Abrir el visual studio code
   - cargar los archivos dentro de la carpeta e2e
	- "APICrearNuevoUsuario.cy.js"
	- "APIUsuarioPasscorrecto.cy.js"
	- "APIUsuarioPassIncorrecto.cy.js"
	- "APIIntentarCrearunUsuarioExistente.cy.js"
   - ejecutar el comando seleccionando el nombre de cada archivo que se desea ejecutar
	


