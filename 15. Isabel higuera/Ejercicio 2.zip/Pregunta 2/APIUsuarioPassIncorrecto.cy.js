describe("Crear Nuevo Usuario",()=>{

    it("Post Crear usuario signup",()=>{
        cypress.request({
            method:'POST',
            url:'https://api.demoblaze.com/login',
            body:{
                username:"imhiguera12",
                password:"1234558"
            }

        })
        .its('status')
        .should('equal',200);

    })


})