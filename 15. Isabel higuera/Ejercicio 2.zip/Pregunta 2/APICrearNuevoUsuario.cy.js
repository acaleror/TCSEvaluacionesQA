describe("Crear Nuevo Usuario",()=>{

    it("Post Crear usuario signup",()=>{
        cypress.request({
            method:'POST',
            url:'https://api.demoblaze.com/signup',
            body:{
                username:"imhiguera11",
                password:"Isa"
            }

        })
        .its('status')
        .should('equal',200);

    })


})