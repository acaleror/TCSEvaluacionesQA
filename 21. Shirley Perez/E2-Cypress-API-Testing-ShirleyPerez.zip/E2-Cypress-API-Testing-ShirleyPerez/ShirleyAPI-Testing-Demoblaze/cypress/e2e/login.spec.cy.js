describe("Prueba de Usuario y password correcto en login", () => {
    it("Debería iniciar sesión con usuario y contraseña correctos", () => {
      const usuarioValido = "usuario_valido";
      const contraseñaValida = "contraseña_valida";
  
      cy.request({
        method: "POST",
        url: "https://api.demoblaze.com/login",
        body: {
          username: usuarioValido,
          password: contraseñaValida,
        },
      }).then((response) => {
        expect(response.status).to.eq(200);
      });
    });
  });
  