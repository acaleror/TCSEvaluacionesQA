describe("Pruebas de API en Demoblaze", () => {
  it("Signup: Crear un nuevo usuario", () => {
    cy.request({
      method: "POST",
      url: "https://api.demoblaze.com/signup",
      body: {
        username: "nuevo_usuario",
        password: "contraseña123",
      },
    }).then((response) => {
      // Verificar que la respuesta tenga un código 200
      expect(response.status).to.eq(200);
      // Puedes realizar más comprobaciones en la respuesta si es necesario.
    });
  });

  it("Login: Iniciar sesión con usuario registrado", () => {
    cy.request({
      method: "POST",
      url: "https://api.demoblaze.com/login",
      body: {
        username: "tu_usuario",
        password: "tu_contraseña",
      },
    }).then((response) => {
      // Verificar que la respuesta tenga un código 200
      expect(response.status).to.eq(200);
      // Puedes realizar más comprobaciones en la respuesta si es necesario.
    });
  });
});
