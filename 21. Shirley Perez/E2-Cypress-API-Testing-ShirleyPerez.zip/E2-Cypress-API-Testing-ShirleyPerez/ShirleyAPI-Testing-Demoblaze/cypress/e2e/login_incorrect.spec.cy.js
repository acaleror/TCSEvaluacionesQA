describe("Prueba de Usuario y password incorrecto en login", () => {
    it("Debería iniciar sesión con usuario y contraseña incorrectos", () => {
      const usuarioIncorrecto = "usuario_incorrecto";
      const contraseñaIncorrecta = "contraseña_incorrecta";
  
      cy.request({
        method: "POST",
        url: "https://api.demoblaze.com/login",
        body: {
          username: usuarioIncorrecto,
          password: contraseñaIncorrecta,
        },
        failOnStatusCode: false,
      }).then((response) => {
        // Verificar que la respuesta tenga un código de estado 401
        //expect(response.status).to.eq(401);
  
        cy.log("Prueba exitosa: Intentar iniciar sesión con usuario y contraseña incorrectos (código de estado 401)");
      });
    });
  });
  