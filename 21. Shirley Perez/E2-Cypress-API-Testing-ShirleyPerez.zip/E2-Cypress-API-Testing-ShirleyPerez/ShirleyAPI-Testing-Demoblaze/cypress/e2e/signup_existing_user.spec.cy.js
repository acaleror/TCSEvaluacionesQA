describe("Prueba de Intentar crear un usuario ya existente en Signup", () => {
    it("Debería intentar crear un usuario ya existente", () => {
      // Definir un usuario que ya existe en tu aplicación (cambia esto según tu caso)
      const usuarioExistente = "usuario_existente";
      const contraseña = "contraseña123";
  
      // Realizar la solicitud de registro para intentar crear el usuario existente
      cy.request({
        method: "POST",
        url: "https://api.demoblaze.com/signup",
        body: {
          username: usuarioExistente,
          password: contraseña,
        },
        failOnStatusCode: false, // Evitar que el código 409 se considere un error
      }).then((response) => {
        // Si se recibe un código 409, considerar la prueba como exitosa
        cy.log("Prueba exitosa: Intentar crear un usuario ya existente (código de estado 409)");
      });
    });
  });
  