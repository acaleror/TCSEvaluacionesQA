Instrucciones para Ejecución de Pruebas de API en Demoblaze

Estas instrucciones detallan cómo ejecutar las pruebas de API en el proyecto "Ejercicio de API" relacionado con la aplicación Demoblaze.

Pasos para Ejecutar las Pruebas de API:

1. Instalar Dependencias:
   - Asegúrate de tener Node.js instalado en tu sistema.
   - Ejecuta el siguiente comando para instalar las dependencias de Cypress en tu proyecto:
     ```
     npm install
     ```

2. Configurar las URL de las Pruebas:
   - Abre los archivos de prueba correspondientes en la carpeta "cypress/e2e".
   - Asegúrate de que las URLs en estos archivos coincidan con las de la aplicación Demoblaze que deseas probar.

3. Ejecutar las Pruebas:
   - Utiliza el siguiente comando para abrir la interfaz de Cypress, que te permitirá seleccionar y ejecutar las pruebas individualmente:
     ```
     npx cypress open
     ```

4. Seleccionar y Ejecutar Pruebas:
   - En la interfaz de Cypress, selecciona la prueba que deseas ejecutar haciendo clic en su nombre.
   - La prueba se ejecutará en una nueva ventana del navegador, y podrás observar su progreso.

5. Revisar Resultados:
   - Cypress mostrará los resultados de la prueba en su interfaz y en la consola.
   - Puedes revisar los detalles de la ejecución y los resultados de cada prueba.

6. Finalizar:
   - Una vez que hayas completado la ejecución de las pruebas, cierra la interfaz de Cypress y la terminal.

Estas instrucciones te guiarán a través del proceso de ejecución de las pruebas de API en Demoblaze. Asegúrate de personalizar las rutas y nombres de archivos según tu proyecto específico.
