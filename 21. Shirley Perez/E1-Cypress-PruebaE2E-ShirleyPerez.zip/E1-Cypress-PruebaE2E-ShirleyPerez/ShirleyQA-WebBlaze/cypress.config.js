const { defineConfig } = require("cypress");

module.exports = defineConfig({
  e2e: {
    setupNodeEvents(on, config) {
      // Implementa los oyentes de eventos de nodo aquí
    },
    specPattern: 'cypress/e2e/*.js', // Usar un patrón de archivos válido
    baseUrl: "https://www.demoblaze.com",
    env: {
      SERENITY: {
        dialect: "cucumber",
        outputDir: "./target/site/serenity" // Ruta relativa a la ubicación de cypress.config.js
      }
    }, 
    viewportWidth: 1600,
    viewportHeight: 900,
  },
});
