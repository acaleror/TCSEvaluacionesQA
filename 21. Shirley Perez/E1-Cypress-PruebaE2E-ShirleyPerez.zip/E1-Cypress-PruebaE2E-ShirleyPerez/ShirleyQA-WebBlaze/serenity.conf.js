const { serenity } = require('@serenity-js/core');
const { Cast, Clock, Serenity, Stage } = require('@serenity-js/core');
const { ConsoleReporter } = require('@serenity-js/console-reporter');
const { Photographer, TakePhotosOfFailures } = require('@serenity-js/protractor');
const { SerenityBDDReporter } = require('@serenity-js/serenity-bdd');
const { Actor, BrowseTheWeb } = require('@serenity-js/core');
const { protractor } = require('protractor');

class ConfiguredActors extends Cast {
  constructor() {
    super();

    this.Alice = Actor.named('Alice').whoCan(BrowseTheWeb.using(protractor.browser));
  }
}

exports.config = {
  actors: new ConfiguredActors(),
  crew: [
    Photographer.whoCan(TakePhotosOfFailures),
    ConsoleReporter.forDarkTerminals(),
    new SerenityBDDReporter(),
  ],
  serenity: new Serenity(new Stage(new Clock()), new Cast()),
  serenityBDD: {
    outputDir: './target/site/serenity', // Ruta de salida de los informes
    crew: [
      // ... Configuraciones adicionales ...
    ],
  },
};
