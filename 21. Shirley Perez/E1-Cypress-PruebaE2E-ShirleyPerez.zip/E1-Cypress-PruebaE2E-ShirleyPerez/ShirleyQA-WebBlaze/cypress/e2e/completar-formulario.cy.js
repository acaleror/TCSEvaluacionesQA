describe('Completa el formulario de compra en DemoBlaze', () => {
  it('Completa el formulario de compra en el modal', () => {
    // Visita la página de DemoBlaze
    cy.visit('https://www.demoblaze.com/');

    // Encuentra y hace clic en un producto (ajusta el selector según tu necesidad)
    cy.contains('Samsung galaxy s6').click();

    // Espera a que la página del producto se cargue completamente
    cy.url().should('include', '/prod.html');

    // Agrega el producto al carrito (suponiendo que hay un botón "Add to cart")
    cy.get('.btn-success').click();

    // Espera a que aparezca el mensaje de éxito (opcional)
    cy.on('window:alert', (message) => {
      expect(message).to.include('Product added');
    });

    // Ve al carrito de compras (suponiendo que hay un enlace al carrito)
    cy.get('#cartur').click();

    // Verifica que estés en la página del carrito (ajusta el selector según tu necesidad)
    cy.url().should('include', '/cart.html');

    // Abre el modal (suponiendo que hay un botón que abre el modal, ajusta el selector según tu necesidad)
    cy.get('#orderModal').click({ force: true }); // Abre el modal usando {force: true}

    // Completa el formulario dentro del modal (ajusta los selectores según tu necesidad)
    cy.get('#name').type('Nombre de Ejemplo', { force: true });
    cy.get('#country').type('País de Ejemplo', { force: true });
    cy.get('#city').type('Ciudad de Ejemplo', { force: true });
    cy.get('#card').type('1234567890123456', { force: true });
    cy.get('#month').type('12', { force: true });
    cy.get('#year').type('2025', { force: true });

    // Verifica que el formulario se haya completado correctamente (ajusta los selectores)
    cy.get('#name').should('have.value', 'Nombre de Ejemplo');
    cy.get('#country').should('have.value', 'País de Ejemplo');
    cy.get('#city').should('have.value', 'Ciudad de Ejemplo');
 

  });
});
