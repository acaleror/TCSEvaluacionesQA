describe('Finaliza la compra en DemoBlaze', () => {
  it('Finaliza la compra después de completar el formulario', () => {
    cy.visit('https://www.demoblaze.com/');

    cy.contains('Samsung galaxy s6').click();
    cy.url().should('include', '/prod.html');
    cy.get('.btn-success').click();
    cy.wait(2000);
    cy.get('#cartur').click();
    cy.url().should('include', '/cart.html');
     
    cy.get('#orderModal').click({ force: true });  
    cy.get('#orderModal', { timeout: 10000 }).should(($modal) => {
      expect($modal).to.have.css('visibility', 'visible');
    });

    cy.get('#name').type('Nombre de Ejemplo', { force: true });
    cy.get('#country').type('País de Ejemplo', { force: true });
    cy.get('#city').type('Ciudad de Ejemplo', { force: true });
    cy.get('#card').type('1234567890123456', { force: true });
    cy.get('#month').type('12', { force: true });
    cy.get('#year').type('2025', { force: true });

    cy.get('.modal-footer').contains('Purchase').click({ force: true });

    
    cy.contains('Thank you for your purchase!').should('be.visible');
  });
});
