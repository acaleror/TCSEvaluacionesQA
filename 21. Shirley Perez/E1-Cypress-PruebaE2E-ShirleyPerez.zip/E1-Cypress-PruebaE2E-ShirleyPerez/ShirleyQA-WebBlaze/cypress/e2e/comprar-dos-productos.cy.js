describe('Prueba de compra en DemoBlaze', () => {
  it('Agrega dos productos al carrito', () => { 
    cy.visit('https://www.demoblaze.com/');
 
    cy.contains('Samsung galaxy s6').click();
 
    cy.url().should('include', '/prod.html');
     
    cy.get('.col-md-7 .btn-success').click();
 
    cy.on('window:alert', (message) => {
      expect(message).to.include('Product added');
    });
 
    cy.visit('https://www.demoblaze.com/');
 
    cy.contains('Nokia lumia 1520').click();
 
    cy.url().should('include', '/prod.html');

    // Agrega el segundo producto al carrito
    cy.get('.col-md-7 .btn-success').click();

    // Espera a que aparezca el mensaje de éxito
    cy.on('window:alert', (message) => {
      expect(message).to.include('Product added');
    });
 
    cy.get('#cartur').click();
 
    cy.get('#tbodyid > tr').should('have.length', 2);
  });
});
