describe('Prueba de compra en DemoBlaze', () => {
    it('Visualiza el carrito', () => {
      cy.log('Iniciando la prueba'); 
      cy.visit('https://www.demoblaze.com/') 
      cy.contains('Samsung galaxy s6').click() 
      cy.url().should('include', '/prod.html') 
      cy.get('.btn-success').click() 
      cy.on('window:alert', (message) => {
        expect(message).to.include('Product added')
      }) 
      cy.get('#cartur').click() 
      cy.url().should('include', '/cart.html')

      cy.log('Prueba completada');
    })
  })
  