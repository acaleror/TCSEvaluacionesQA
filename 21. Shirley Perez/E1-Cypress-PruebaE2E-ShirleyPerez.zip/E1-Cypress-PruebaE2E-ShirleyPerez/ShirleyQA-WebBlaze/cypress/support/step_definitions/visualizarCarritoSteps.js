describe('Prueba de Compra en DemoBlaze', () => {
    it('Agrega un producto al carrito y verifica su visualización', () => {
      // Abre la página de inicio de DemoBlaze
      cy.visit('https://www.demoblaze.com/');
  
      // Encuentra y hace clic en un producto para agregarlo al carrito
      cy.get('.card-title').first().click(); // Puedes ajustar el selector según tus necesidades
  
      // Espera a que la página de producto cargue
      cy.url().should('include', '/product.html'); // Ajusta la URL según tus necesidades
  
      // Encuentra y hace clic en el botón "Add to cart" para agregar el producto al carrito
      cy.get('#addToCart').click(); // Ajusta el selector según tus necesidades
  
      // Espera a que aparezca una notificación de éxito o cualquier otro elemento que indique
      // que el producto se ha agregado al carrito
      cy.contains('Product added').should('be.visible'); // Ajusta el texto según tus necesidades
  
      // Verifica que el carrito se visualice correctamente
      cy.get('#cartur').click(); // Hace clic en el icono del carrito
  
      // Verifica que el producto esté en el carrito (puedes ajustar el selector)
      cy.get('.success > :nth-child(1)').should('be.visible'); // Ajusta el selector según tus necesidades
    });
  });
  