const { Given, When, Then } = require('cypress-cucumber-preprocessor/steps');

Given('I am on the product page', () => {
  // Navegas a la página de un producto
  // Asegúrate de adaptar el URL al producto específico que deseas en tu escenario
  cy.visit('https://www.demoblaze.com/prod.html?id=1');
});

When('I add the first product to the cart', () => {
  // Haces clic en el botón "Add to cart" para el primer producto
  cy.get('.btn-success').first().click();
});

When('I add the second product to the cart', () => {
  // Haces clic en el botón "Add to cart" para el segundo producto
  cy.get('.btn-success').eq(1).click();
});

Then('I should see two products in the cart', () => {
  // Verificas que haya dos productos en el carrito
  cy.get('#tbodyid > tr').should('have.length', 2);
});
