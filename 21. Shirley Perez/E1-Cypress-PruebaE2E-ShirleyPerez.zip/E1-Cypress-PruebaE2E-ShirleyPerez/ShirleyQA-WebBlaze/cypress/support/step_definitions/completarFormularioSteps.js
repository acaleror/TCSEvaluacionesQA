const { Given, When, Then } = require('cypress-cucumber-preprocessor/steps');

// Supongamos que tienes una página donde puedes completar un formulario de compra

Given('I am on the purchase form page', () => {
  // En este paso, navegas a la página del formulario de compra
  cy.visit('https://www.demoblaze.com/purchase.html');
});

When('I fill in the purchase form with valid information', () => {
  // En este paso, completas el formulario con información válida
  cy.get('#name').type('John Doe');
  cy.get('#country').type('United States');
  cy.get('#city').type('New York');
  cy.get('#card').type('1234567890123456');
  cy.get('#month').type('12');
  cy.get('#year').type('2024');
});

When('I submit the form', () => {
  // En este paso, envías el formulario
  cy.get('#orderModalLabel > .btn').click();
});

Then('I should see a purchase confirmation', () => {
  // En este paso, verificas que se muestre la confirmación de compra
  cy.get('#orderModalLabel').should('be.visible');
});
