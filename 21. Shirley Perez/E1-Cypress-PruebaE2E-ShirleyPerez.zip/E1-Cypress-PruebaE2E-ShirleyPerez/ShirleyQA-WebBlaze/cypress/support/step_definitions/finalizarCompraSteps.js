const { Given, When, Then } = require('cypress-cucumber-preprocessor/steps');

Given('I am on the checkout page', () => {
  // Navegas a la página de finalización de compra
  cy.visit('https://www.demoblaze.com/checkout.html');
});

When('I fill in the checkout form with valid information', () => {
  // Completas el formulario de finalización de compra con información válida
  cy.get('#name').type('John Doe');
  cy.get('#country').type('United States');
  cy.get('#city').type('New York');
  cy.get('#card').type('1234567890123456');
  cy.get('#month').type('12');
  cy.get('#year').type('2024');
});

When('I click the "Purchase" button', () => {
  // Haces clic en el botón "Purchase"
  cy.get('.btn.btn-success').click();
});

Then('I should see a purchase confirmation', () => {
  // Verificas que se muestre la confirmación de compra
  cy.get('#orderModalLabel').should('be.visible');
});
