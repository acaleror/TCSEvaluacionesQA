----------------------------------------------------------------
INSTRUCCIONES PARA EJECUTAR LAS PRUEBAS EN DEMOBLAZE 
----------------------------------------------------------------


Este documento proporciona instrucciones detalladas sobre cómo ejecutar las pruebas automatizadas en el sitio web DemoBlaze utilizando Cypress. Siga estos pasos cuidadosamente para garantizar una ejecución exitosa de las pruebas.


----------------------------------------------------------------
REQUISITOS PREVIOS
----------------------------------------------------------------

Antes de comenzar con la ejecución de las pruebas automatizadas en el sitio web DemoBlaze utilizando Cypress, asegúrese de cumplir con los siguientes requisitos previos en su sistema:

- Node.js: Asegúrese de que Node.js esté instalado en su sistema. Puede descargarlo desde https://nodejs.org/.


----------------------------------------------------------------
PASOS PARA EJECUTAR LAS PRUEBAS EN DEMOBLAZE
----------------------------------------------------------------

PASO 1: Navegar a la Carpeta del Proyecto

- Abra una terminal o línea de comandos en su sistema.

- Navegue hasta la carpeta donde se encuentra el proyecto. Puede hacerlo utilizando el siguiente comando:

cd /ruta/a/la/carpeta/del/proyecto

NOTA: Reemplace /ruta/a/la/carpeta/del/proyecto con la ubicación real de la carpeta del proyecto en su sistema.

PASO 2: Instalación de Cypress

- Dentro de la carpeta del proyecto, realice la instalación de Cypress utilizando el siguiente comando para instalarlo globalmente en su sistema (asegúrese de haber cumplido con el requisito previo de Node.js):

npm install -g cypress

PASO 3: Abrir la Interfaz de Cypress

- Ejecute el siguiente comando para abrir la interfaz de Cypress en una ventana de su navegador:

npx cypress open

NOTA: Esto iniciará la interfaz de Cypress y la abrirá en su navegador web predeterminado.

PASO 4: Seleccionar y Ejecutar las Pruebas

- En la interfaz de Cypress, verá una lista de archivos de prueba.

- Seleccione el archivo de prueba que desea ejecutar (por ejemplo, 'visualizar-carrito.cy.js') haciendo clic en él.

NOTA: Cypress abrirá una ventana de navegador y ejecutará las pruebas automáticamente.

PASO 5: Observar la Ejecución de las Pruebas

- Observe la ejecución de las pruebas y verifique que todas sean exitosas.

NOTA: Puede seguir el progreso de las pruebas y revisar los resultados en la ventana de Cypress.

PASO 6: Ejecutar Pruebas desde la Línea de Comandos (Opcional)

- Si desea ejecutar una prueba específica desde la línea de comandos, puede utilizar el siguiente comando:

npx cypress run --spec cypress/e2e/nombre-de-la-prueba.cy.js

NOTA: Esto ejecutará la prueba seleccionada y mostrará los resultados en la terminal.

PASO 7: Revisar Informes

- Después de completar las pruebas, puede revisar los informes generados por Cypress en la carpeta './cypress/screenshots'.

NOTA: Tenga en cuenta que esta configuración está diseñada para capturar capturas de pantalla solo si ocurren errores. Si no hay errores en las pruebas, no se generarán capturas de pantalla ni informes.