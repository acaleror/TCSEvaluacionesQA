# Prueba de Compra en DemoBlaze - Proyecto ShirleyTester

Este proyecto, llamado ShirleyTester, demuestra cómo realizar pruebas automatizadas de compra en el sitio web de DemoBlaze utilizando Cucumber y Serenity BDD.

## Requisitos

Asegúrate de tener las siguientes herramientas instaladas en tu entorno de desarrollo:

- [Java Development Kit (JDK)](https://www.oracle.com/java/technologies/javase-downloads.html)
- [Maven](https://maven.apache.org/download.cgi)
- [IntelliJ IDEA](https://www.jetbrains.com/idea/download/) (u otra IDE de tu elección)
- Controlador de Chrome (para las pruebas de Selenium)

## Configuración del Proyecto

1. Descarga el archivo comprimido `E1-Serenity-Cucumber-PruebaE2E-ShirleyPerez.rar`.

2. Descomprime el archivo en un directorio de tu elección.

3. Abre el proyecto en tu IDE.

4. Asegúrate de que Maven descargue todas las dependencias necesarias.

## Ejecución de las Pruebas

Para ejecutar las pruebas de compra en DemoBlaze con el proyecto ShirleyTester, sigue estos pasos:

1. Abre el proyecto en tu IDE y en la raíz del proyecto ejecuta la siguiente linea de comando:
mvn clean verify
2. Visualiza los reportes generados en la carpeta target/site/serenity/index.html

