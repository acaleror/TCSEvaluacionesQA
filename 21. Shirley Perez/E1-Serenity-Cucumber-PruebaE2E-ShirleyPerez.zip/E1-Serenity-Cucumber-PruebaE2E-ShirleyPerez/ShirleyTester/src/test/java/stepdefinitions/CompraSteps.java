package stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.serenitybdd.screenplay.actions.Open;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.waits.WaitUntil;
import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import static net.serenitybdd.screenplay.matchers.WebElementStateMatchers.isVisible;
import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.matchers.ConsequenceMatchers.displays;

public class CompraSteps {
    private Actor actor;
    private WebDriver driver;

    private Target productName = Target.the("Nombre del producto").located(By.linkText("Samsung galaxy s6"));
    private Target addToCartButton = Target.the("Botón 'Add to cart'").located(By.linkText("Add to cart"));
    private Target cartLink = Target.the("Enlace al carrito").located(By.id("cartur"));

    @Given("que estoy en la página de inicio de DemoBlaze")
    public void estoy_en_la_página_de_inicio_de_DemoBlaze() {
        actor = Actor.named("Usuario de DemoBlaze");
        actor.can(BrowseTheWeb.with(driver));
        actor.attemptsTo(Open.url("https://www.demoblaze.com/"));
    }

    @When("agrego un producto al carrito")
    public void agrego_un_producto_al_carrito() {
        actor.attemptsTo(Click.on(productName));
        actor.attemptsTo(WaitUntil.the(addToCartButton, isVisible()).forNoMoreThan(10).seconds());
        actor.attemptsTo(Click.on(addToCartButton));

    }

    @When("voy al carrito")
    public void voy_al_carrito() {

        actor.attemptsTo(Click.on(cartLink));
    }

    @Then("debería ver el producto en el carrito")
    public void debería_ver_el_producto_en_el_carrito() {
        Target productNameCell = Target.the("Celda del nombre del producto").locatedBy("//td[contains(text(),'Samsung galaxy s6')]");
        actor.attemptsTo(
                WaitUntil.the(productNameCell, isVisible()).forNoMoreThan(10).seconds()
        );
        actor.attemptsTo(Click.on(productNameCell));
    }

}
