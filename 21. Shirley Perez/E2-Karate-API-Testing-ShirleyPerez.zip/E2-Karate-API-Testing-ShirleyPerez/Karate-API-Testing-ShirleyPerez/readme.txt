# Karate API Testing - Ejercicio 2

## Descripción
Este proyecto contiene pruebas de API automatizadas utilizando Karate. Las pruebas están diseñadas para interactuar con la API de Demoblaze (https://www.demoblaze.com/), incluyendo pruebas de registro e inicio de sesión.

## Requisitos Previos
Instrucciones para la Ejecución del Proyecto:

- JDK (Java Development Kit): Asegúrese de contar con una versión compatible del JDK instalada en su sistema. Se recomienda JDK 8 o superior. Puede descargar el JDK desde Oracle.

- Maven: Verifique que Maven esté instalado en su sistema. 

## Pasos para Ejecutar el Proyecto:

- Terminal o Línea de Comandos: Abra una terminal o línea de comandos en su computadora.

- Navegación al Directorio del Proyecto: Utilice el comando cd para navegar hasta el directorio raíz del proyecto. Por ejemplo, si descomprimiste el archivo en el escritorio, ejecuta:

cd Desktop/Karate-API-Testing-ShirleyPerez


## Ejecución de Pruebas

- Para ejecutar las pruebas de API, utilice Maven con el siguiente comando:

mvn test

- Maven descargará automáticamente las dependencias del proyecto y ejecutará las pruebas de Karate. El progreso y los resultados de las pruebas se mostrarán en la terminal.

## Informes de Pruebas

- Una vez que las pruebas se completen con éxito, los informes de Karate estarán disponibles en la carpeta target/karate-reports. 
- Abra el archivo karate-summary.html en su navegador web para obtener una visión general de la ejecución de las pruebas.
