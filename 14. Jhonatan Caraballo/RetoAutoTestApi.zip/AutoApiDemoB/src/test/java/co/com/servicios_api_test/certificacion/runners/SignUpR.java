package co.com.servicios_api_test.certificacion.runners;

import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import org.junit.runner.RunWith;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(
        features = "src/test/resources/features/signup.feature",
        glue = "co.com.servicios_api_test.certificacion.StepDefinitions"

)

public class SignUpR {
}