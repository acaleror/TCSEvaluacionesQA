package co.com.servicios_api_test.certificacion.StepDefinitions.commons;


import co.com.servicios_api_test.certificacion.questions.ValidacionDeRespuestaOk;
import co.com.servicios_api_test.certificacion.tasks.signup.SignUp;
import co.com.servicios_api_test.certificacion.tasks.signup.SignUpOk;
import co.com.servicios_api_test.certificacion.utilidades.BeforeHook;
import co.com.servicios_api_test.certificacion.utilidades.GestionarDatos;
import co.com.servicios_api_test.certificacion.utilidades.SeleniumFunctions;
import cucumber.api.java.es.Cuando;
import cucumber.api.java.es.Dado;
import cucumber.api.java.es.Entonces;
import io.restassured.response.Response;
import org.json.JSONObject;

import java.io.IOException;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;


public class SignUpStep {

    SeleniumFunctions functions = new SeleniumFunctions();
    GestionarDatos Data = new GestionarDatos();
    Response response;
    JSONObject jsonBodyRequest;

    @Dado("^que Jhonatan usa el servicio (.*)")
    @Cuando("^Jhonatan consume el servicio de (.*)$")
    public void consumoDeServicio(String urlBase) throws IOException {
        functions.retrieveTestData(urlBase);
        BeforeHook.prepareStage(functions.getScenarioData(urlBase));

    }

    @Cuando("Jhonatan se autentica en la pagina con correo (.*)$")
    public void elCreaCuentaOK(String userType) {
        theActorInTheSpotlight().attemptsTo(SignUp.signUp(userType));
    }

    @Entonces("^se vera codigo status (.*) con mensaje$")
    public void validateCreation(int statusCode) {
        theActorInTheSpotlight().should(seeThat(ValidacionDeRespuestaOk.es(statusCode)));
    }
}

