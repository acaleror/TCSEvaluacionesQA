package co.com.servicios_api_test.certificacion.utilidades.enums.enumsEncrypt;

public enum EnumMsgEncrypt {
  PHRASSE_SECURITY("qualityinfosolutions"),
  ENCRYPT_ERROR("An error occurred while encrypting"),
  DECRYPT_ERROR("An error occurred while decrypting");

  private final String mensaje;

  EnumMsgEncrypt(String mensaje) {
    this.mensaje = mensaje;
  }

  public String getMensaje() {
    return mensaje;
  }
}
