package co.com.servicios_api_test.certificacion.questions;


import co.com.servicios_api_test.certificacion.model.DataAutenticacion.AutenticacionDataResponse;
import co.com.servicios_api_test.certificacion.utilidades.SeleniumFunctions;
import io.restassured.response.Response;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import org.junit.Assert;



public class ValidacionDeRespuesta implements Question<Boolean> {

    SeleniumFunctions functions = new SeleniumFunctions();

    private final int statusCode;

    public ValidacionDeRespuesta(int statusCode ) {
        this.statusCode = statusCode;

    }

    public static ValidacionDeRespuesta es(int statusCode) {
        return new ValidacionDeRespuesta(statusCode);
    }

        @Override
    public Boolean answeredBy(Actor actor) {

            Assert.assertEquals(statusCode, SerenityRest.lastResponse().statusCode());
            return true;
        }

}
