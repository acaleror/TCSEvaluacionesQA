package co.com.servicios_api_test.certificacion.utilidades;

public enum EndPointsDemoBlaze {
    CREAR_CUENTA("/signup"),
    INICIAR_SESION("/login");


    private final String uri;

    EndPointsDemoBlaze(String uri) {
        this.uri = uri;
    }

    @Override
    public String toString() { return uri; }

}



