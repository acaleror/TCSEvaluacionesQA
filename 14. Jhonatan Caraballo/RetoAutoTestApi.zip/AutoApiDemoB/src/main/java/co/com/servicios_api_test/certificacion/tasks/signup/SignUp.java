package co.com.servicios_api_test.certificacion.tasks.signup;

import co.com.servicios_api_test.certificacion.tasks.login.LoginFailed;
import co.com.servicios_api_test.certificacion.tasks.login.LoginOk;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;

import static net.serenitybdd.screenplay.Tasks.instrumented;

public class SignUp implements Task {

    private final String userType;

    public SignUp(String userType) {
        this.userType = userType;
    }

    public static SignUp signUp(String userType) {
        return instrumented(SignUp.class, userType);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        switch (userType) {
            case "No Registrado Previamente":
                signUpOk(actor);
                break;
            default:
                signUpFailed(actor);
                break;
        }
    }

    private void signUpOk(Actor actor) {
        actor.attemptsTo(
                SignUpOk.toRecord());
    }

    private void signUpFailed(Actor actor) {
        actor.attemptsTo(
                SignUpFailed.toRecord());
    }
}