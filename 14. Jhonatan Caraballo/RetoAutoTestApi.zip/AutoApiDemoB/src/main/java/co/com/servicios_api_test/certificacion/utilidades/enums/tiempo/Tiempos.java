package co.com.servicios_api_test.certificacion.utilidades.enums.tiempo;

public enum Tiempos {
    TIEMPO_INICIAL("Tiempo Inicial"),
    INITIAL_TIME("Tiempo Inicial"),
    TIEMPO_FINAL("Tiemop final");
    private final String tiempos;

    Tiempos(String tiempos) {
        this.tiempos = tiempos;
    }

    @Override
    public String toString() { return tiempos; }
}
