package co.com.servicios_api_test.certificacion.model.DataAutenticacion;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class AutenticacionDataResponse {
    private String       firstname;
    private String       lastname;
    private int          totalprice;
    private boolean      depositpaid;
    private String       additionalneeds;
}