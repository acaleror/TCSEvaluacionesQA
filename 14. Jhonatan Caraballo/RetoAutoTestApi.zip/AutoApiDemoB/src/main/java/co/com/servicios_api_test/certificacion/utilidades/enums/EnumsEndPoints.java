package co.com.servicios_api_test.certificacion.utilidades.enums;

public enum EnumsEndPoints {
    CREAR_SESION("/dar/v4/public/auth/login"),
    TOMAR_OFERTAS("/api/v2.0/mobile/planmigrate/subscribers/50360072736/form"),
    PAGAR_OFERTA("/api/v2.0/payment/mobile/packets/subscribers/75066349/purchaseorders/4d7a597a4d544d334d7a4d3d?targetMsisdn=75066349&_format=json"),
    CONSULTAR_OFERTAS("/api/v2.0/mobile/planmigrate/subscribers/%s/pretopos"),
    CONSULTAR_OFERTAS_POSTPAGO("/api/v2.0/mobile/planmigrate/subscribers/72843795/pretopos");

    private final String endPoints;

    EnumsEndPoints(String endPoints) {
        this.endPoints = endPoints;
    }

    @Override
    public String toString() { return endPoints; }
}
