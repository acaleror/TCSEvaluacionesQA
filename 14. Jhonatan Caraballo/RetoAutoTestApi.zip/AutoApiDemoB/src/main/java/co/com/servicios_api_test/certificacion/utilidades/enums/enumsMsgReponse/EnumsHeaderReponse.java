//package co.com.servicios_api_test.certificacion.utilidades.enums.enumsMsgReponse;
//
//public enum EnumsHeaderReponse {
//
//    MSG_PASS_WRONG("errorMessage"),
//    MSG_SUCCESS_LOGIN("Auth_token"),
//    MSG_IDTOKEN_LOGIN("ZGF2aWQwMUBnbWFpbC5jb20xNjkxMTcw"),
//    PATH_IDTOKEN("Auth_token");
//
//    private final String endPoints;
//
//    EnumsHeaderReponse(String endPoints) {
//        this.endPoints = endPoints;
//    }
//
//    @Override
//    public String toString() {
//        return endPoints; }
//}
