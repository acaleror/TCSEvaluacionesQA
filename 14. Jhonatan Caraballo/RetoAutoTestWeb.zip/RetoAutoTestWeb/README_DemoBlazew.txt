
# Pruebas Automatizadas  - Jhonatan Caraballo - Automatizador

## Pre-requisitos
- Java JDK 1.8 (variables de entorno configuradas)
- Gradle v7.0.0 o superior (variables de entorno configuradas)
- Serenity BDD Cucumber + Gherkin
- Screenplay 
- IntelliJ IDEA
- Broswer Chrome

## Pasos para configurar proyecto

- Clonar el repositorio con el siguiente comando: git clone ```  ```
- Importar el proyecto de gradle ``` ```

## Pruebas Diseñadas


## Flujo para la ejecución de pruebas

1. Definir Estrategia de Ejecución
2. Codificación de la prueba
3.Ejecutar pruebas
4.Generar reporte del serenity
5. Guardar reporte de ejecución


4. asd

- Ejecutar todas las pruebas ```gradle clean test aggregate```

## Como contribuir al proyecto

- Las pruebas están enfocadas en los flujos críticos del aplicativo de acuerdo a las reglas del negocio y requerimientos de los StakeHolders

## Crear Pruebas

1. Definir Story
2. Crear Flujo de la Funcionalidad 
3. Definir Escenario feliz de la mano con el negocio
4. Definir Escenarios alternos usando técnicas de diseño de caja negra
5. Crear runner para su ejecución

## Estructura del proyecto

* ```src/main/java```
``` 

+ SummaAgileBenefitsManualTest

    + Clase: ManualTest.java
    Clase con la se realiza la ejecucón manual de los casos de prueba
    
````
* ```src/test/java```
``` 

+ src/test/java/creditos01/runners
    Clases que permiten la ejecución de las pruebas. 

+ src.test.java.creditos01.stepdefinitions
    Clases donde se acopla el lenguaje Gherkin con que se escriben los escenarios y el código java que va a ser ejecutado para la automatización. 

``` 
* ```src/test/resources```
``` 

+ features
    Archivos donde se escriben los escenarios o historias que lleva a cabo el usuario a nivel de negocio.  

````
## Versionamiento

- Versionamiento basado en Trunk Based Development 

## Autores

* **Jhonatan David Caraballo Ortiz** - Automatizador QA* - [jhonatan.c@tcs.com]



