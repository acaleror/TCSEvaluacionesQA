package co.com.tcs.certificacion.userinterfaces;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class ProductPurchaseUser {

    public static final Target PROD_SAMSUNG_GS6=Target.the("Selección de Samsung galaxy s6").locatedBy("//*[contains(text(),'Samsung galaxy s6')]");
    public static final Target ADD_TO_CART=Target.the("Button Add to cart").locatedBy("//*[contains(text(),'Add to cart')]");
    public static final Target BTN_HOME_PAGE=Target.the("Button Home page").locatedBy("//*[contains(text(),'Home')]");
    public static final Target PROD_SONY_SPERIA=Target.the("Selección de Sony xperia z5").locatedBy("//*[contains(text(),'Sony xperia z5')]");
    public static final Target CART_SCREEN=Target.the("Pantalla cart").locatedBy("//*[contains(text(),'Cart')]");
    public static final Target BTN_PLACE_ORDER=Target.the("Btn ordenar compra").locatedBy("//*[contains(text(),'Place Order')]");
    public static final Target BOX_NAME=Target.the("Caja nombre").located(By.id("name"));
    public static final Target BOX_COUNTRY=Target.the("Caja Pais").located(By.id("country"));
    public static final Target BOX_CITY=Target.the("Caja Ciudad").located(By.id("city"));
    public static final Target BOX_CREDIT_CARD=Target.the("Caja tarjeta de crédito").located(By.id("card"));
    public static final Target BOX_MONTH=Target.the("Caja mes").located(By.id("month"));
    public static final Target BOX_YEAR=Target.the("Caja mes").located(By.id("year"));
    public static final Target BTN_PURCHASEE=Target.the("BTN Purchase").locatedBy("//*[contains(text(),'Purchase')]");
    public static final Target VALIDATE_PURCHASEE=Target.the("VALIDATE Purchase").locatedBy("//*[contains(text(),'Thank you for your purchase!')]");



    }
