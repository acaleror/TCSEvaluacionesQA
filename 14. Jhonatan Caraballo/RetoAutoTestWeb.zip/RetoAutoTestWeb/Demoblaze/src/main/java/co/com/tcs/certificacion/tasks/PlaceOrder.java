package co.com.tcs.certificacion.tasks;

import co.com.tcs.certificacion.interactions.Wait;
import co.com.tcs.certificacion.interactions.WaitElement;
import lombok.SneakyThrows;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.SendKeys;

import java.awt.*;
import java.awt.event.KeyEvent;

import static co.com.tcs.certificacion.userinterfaces.ProductPurchaseUser.*;
import static net.serenitybdd.screenplay.Tasks.instrumented;

public class PlaceOrder implements Task {
    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                WaitElement.isPresent(BTN_PLACE_ORDER),
                Click.on(BTN_PLACE_ORDER),
                SendKeys.of("Jhonatan Caraballo").into(BOX_NAME),
                SendKeys.of("Colombia").into(BOX_COUNTRY),
                SendKeys.of("Bogotá").into(BOX_CITY),
                SendKeys.of("123456789").into(BOX_CREDIT_CARD),
                SendKeys.of("Agosto").into(BOX_MONTH),
                SendKeys.of("2023").into(BOX_YEAR),
                Click.on(BTN_PURCHASEE),
                Wait.aTime(5000)
                );
    }
    public static PlaceOrder product2() {
        return instrumented(PlaceOrder.class);
  }
}
