package co.com.tcs.certificacion.model;

public class C {
}
