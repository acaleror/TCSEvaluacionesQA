package co.com.tcs.certificacion.questions;

import co.com.tcs.certificacion.interactions.WaitElement;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

import static co.com.tcs.certificacion.userinterfaces.ProductPurchaseUser.ADD_TO_CART;
import static co.com.tcs.certificacion.userinterfaces.ProductPurchaseUser.VALIDATE_PURCHASEE;

public class ValidatePurchase implements Question<Boolean> {

    @Override
    public Boolean answeredBy(Actor actor) {
        if(VALIDATE_PURCHASEE.resolveFor(actor).isVisible())
            return true;
        return false;
    }
    public static ValidatePurchase inPage() {
        return new ValidatePurchase();
    }
}

