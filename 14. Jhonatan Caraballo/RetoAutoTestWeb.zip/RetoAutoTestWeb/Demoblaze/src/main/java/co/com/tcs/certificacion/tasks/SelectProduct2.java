package co.com.tcs.certificacion.tasks;

import co.com.tcs.certificacion.interactions.Wait;
import co.com.tcs.certificacion.interactions.WaitElement;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Click;

import java.awt.*;
import java.awt.event.KeyEvent;

import static co.com.tcs.certificacion.userinterfaces.ProductPurchaseUser.*;
import static net.serenitybdd.screenplay.Tasks.instrumented;

public class SelectProduct2 implements Task {

    Robot r = new Robot();

    public SelectProduct2() throws AWTException {
    }


    @Override
    public <T extends Actor> void performAs(T actor) {


        actor.attemptsTo(
                Wait.aTime(10000),
                WaitElement.isPresent(BTN_HOME_PAGE),
                Click.on(BTN_HOME_PAGE),
                Wait.aTime(20000),
                WaitElement.isPresent(PROD_SONY_SPERIA),
                Click.on(PROD_SONY_SPERIA),
                WaitElement.isPresent(ADD_TO_CART),
                Click.on(ADD_TO_CART));

        r.keyPress(KeyEvent.VK_ESCAPE);
        r.keyRelease(KeyEvent.VK_ESCAPE);
        Wait.aTime(10000);

        actor.attemptsTo(
                WaitElement.isPresent(CART_SCREEN),
                Click.on(CART_SCREEN),
                Wait.aTime(20000));
    }
    public static SelectProduct2 product2() {
        return instrumented(SelectProduct2.class);
  }
}
