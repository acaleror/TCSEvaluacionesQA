package co.com.tcs.certificacion.tasks;

import co.com.tcs.certificacion.interactions.Wait;
import co.com.tcs.certificacion.interactions.WaitElement;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Click;

import java.awt.*;
import java.awt.event.KeyEvent;

import static co.com.tcs.certificacion.userinterfaces.ProductPurchaseUser.*;
import static net.serenitybdd.screenplay.Tasks.instrumented;
public class SelectProduct1 implements Task {

    Robot r = new Robot();

    public SelectProduct1() throws AWTException {
    }


    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                WaitElement.isPresent(PROD_SAMSUNG_GS6),
                Click.on(PROD_SAMSUNG_GS6),
                WaitElement.isPresent(ADD_TO_CART),
                Click.on(ADD_TO_CART)
                );
                r.keyPress(KeyEvent.VK_ESCAPE);
                r.keyRelease(KeyEvent.VK_ESCAPE);
                Wait.aTime(10000);
    }
    public static SelectProduct1 product1() {
        return instrumented(SelectProduct1.class);
  }
}
