package co.com.tcs.certificacion.stepdefinitions;

import co.com.tcs.certificacion.interactions.HomePage;
import co.com.tcs.certificacion.questions.ValidatePurchase;
import co.com.tcs.certificacion.tasks.PlaceOrder;
import co.com.tcs.certificacion.tasks.SelectProduct1;
import co.com.tcs.certificacion.tasks.SelectProduct2;
import io.cucumber.java.en.*;
import net.serenitybdd.screenplay.actors.OnStage;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;

public class ProductPurchaseStep {
    @Given("^que el abre pagina principal demoblaze$")
    public void queElAbrePaginaPrincipal() {
        theActorInTheSpotlight().attemptsTo(
                HomePage.inPage());
    }
    @When("^el selecciona producto$")
    public void elSeleccionaProducto() {
        theActorInTheSpotlight().attemptsTo(
                SelectProduct1.product1());
        theActorInTheSpotlight().attemptsTo(
                SelectProduct2.product2());
    }

    @And("^registra sus datos para comprar el producto$")
    public void gestorIniciaSesionFromDirAct( ) {
        theActorInTheSpotlight().attemptsTo(
                PlaceOrder.product2());
    }
    @Then("^se vera pantalla de inicio$")
    public void seVeraEnPantalla() {
        theActorInTheSpotlight().should(seeThat(ValidatePurchase.inPage()));
    }
}
